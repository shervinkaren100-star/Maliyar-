package com.example.mali_yar

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import java.text.NumberFormat
import java.util.Locale

private data class Tx(val title:String, val amount:Long, val income:Boolean)
private fun money(n:Long)=NumberFormat.getNumberInstance(Locale("fa","IR")).format(n)+" تومان"

class MainActivity: ComponentActivity(){ override fun onCreate(b:Bundle?){super.onCreate(b); setContent{MaliYarApp()}} }

@Composable fun MaliYarApp(){
 var tab by remember{mutableIntStateOf(0)}
 var txs by remember{mutableStateOf(listOf(Tx("حقوق",35000000,true),Tx("خرید روزانه",-850000,false),Tx("سرمایه‌گذاری",-5000000,false)))}
 var showAdd by remember{mutableStateOf(false)}
 val income=txs.filter{it.income}.sumOf{it.amount}; val expense=-txs.filter{!it.income}.sumOf{it.amount}; val balance=income-expense
 CompositionLocalProvider(LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl){
  Scaffold(bottomBar={NavigationBar{listOf("خانه","تراکنش‌ها","بودجه","دارایی‌ها","گزارش").forEachIndexed{i,s->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Text(listOf("⌂","↕","◉","◆","▥")[i],fontSize=20.sp)},label={Text(s)})}}}, floatingActionButton={if(tab==0||tab==1) FloatingActionButton(onClick={showAdd=true}){Text("+")}}){pad->
   Box(Modifier.fillMaxSize().padding(pad).background(MaterialTheme.colorScheme.surface)){when(tab){0->Home(income,expense,balance,txs);1->Transactions(txs);2->Budget(expense);3->Assets();4->Reports(income,expense)}}
  }
 }
 if(showAdd) AddTx({title,amount,incomeFlag->txs=txs+Tx(title,amount,incomeFlag);showAdd=false},{showAdd=false})
}

@Composable fun Header(title:String){Column(Modifier.padding(20.dp)){Text(title,fontSize=28.sp,fontWeight=FontWeight.Bold);Text("مدیریت ساده و هوشمند پول شما",color=MaterialTheme.colorScheme.onSurfaceVariant)}}
@Composable fun CardBox(content:@Composable ColumnScope.()->Unit)=Card(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=6.dp),shape=RoundedCornerShape(20.dp)){Column(Modifier.padding(18.dp),content=content)}
@Composable fun Home(i:Long,e:Long,b:Long,txs:List<Tx>){LazyColumn{item{Header("داشبورد مالی")};item{CardBox{Text("موجودی فعلی",color=MaterialTheme.colorScheme.onSurfaceVariant);Text(money(b),fontSize=27.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(14.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("درآمد\n${money(i)}",color=MaterialTheme.colorScheme.primary);Text("هزینه\n${money(e)}",color=MaterialTheme.colorScheme.error)}}};item{CardBox{Text("روند ۶ ماه اخیر",fontWeight=FontWeight.Bold);Spacer(Modifier.height(10.dp));MiniChart()}};item{Text("آخرین تراکنش‌ها",fontSize=20.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(20.dp,16.dp,20.dp,4.dp))};items(txs.takeLast(5).reversed()){TxRow(it)}}}
@Composable fun MiniChart(){Canvas(Modifier.fillMaxWidth().height(150.dp)){val p=Path();val vals=listOf(.35f,.5f,.42f,.7f,.62f,.86f);vals.forEachIndexed{x,y->{val xx=size.width*x/(vals.size-1);val yy=size.height*(1-y);if(x==0)p.moveTo(xx,yy)else p.lineTo(xx,yy)}};drawPath(p,style=Stroke(width=7f));}}
@Composable fun TxRow(t:Tx){Row(Modifier.fillMaxWidth().padding(horizontal=20.dp,vertical=9.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column{Text(t.title,fontWeight=FontWeight.SemiBold);Text(if(t.income)"درآمد" else "هزینه",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)};Text((if(t.income)"+" else "-")+money(kotlin.math.abs(t.amount)),color=if(t.income)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)}}
@Composable fun Transactions(txs:List<Tx>){LazyColumn{item{Header("تراکنش‌ها")};items(txs.reversed()){TxRow(it)}}}
@Composable fun Budget(expense:Long){LazyColumn{item{Header("بودجه ماهانه")};item{CardBox{Text("سقف هزینه ماهانه");Text("۲۰٬۰۰۰٬۰۰۰ تومان",fontSize=25.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));LinearProgressIndicator(progress={(expense/20000000f).coerceIn(0f,1f)},modifier=Modifier.fillMaxWidth());Text("مصرف‌شده: ${money(expense)}",modifier=Modifier.padding(top=8.dp))}};item{CardBox{Text("دسته‌ها",fontWeight=FontWeight.Bold);Text("خوراک و روزمره     ۴۰٪");Text("قبوض و خانه          ۲۵٪");Text("تفریح                  ۱۵٪");Text("سایر                    ۲۰٪")}}}}
@Composable fun Assets(){LazyColumn{item{Header("دارایی‌ها")};listOf("حساب بانکی" to "۴۵٬۰۰۰٬۰۰۰ تومان","طلا" to "۱۲۰٬۰۰۰٬۰۰۰ تومان","سهام" to "۲۸۰٬۰۰۰٬۰۰۰ تومان","خودرو" to "۹۰۰٬۰۰۰٬۰۰۰ تومان").forEach{(a,v)->item{CardBox{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(a,fontWeight=FontWeight.Bold);Text(v)}}}}}}
@Composable fun Reports(i:Long,e:Long){LazyColumn{item{Header("گزارش مالی")};item{CardBox{Text("پس‌انداز ماه");Text(money(i-e),fontSize=27.sp,fontWeight=FontWeight.Bold);Text("نرخ پس‌انداز: ${if(i>0)((i-e)*100/i)else 0}%")}};item{CardBox{Text("اهداف مالی",fontWeight=FontWeight.Bold);Text("صندوق اضطراری   ۶۵٪");LinearProgressIndicator(progress={.65f},Modifier.fillMaxWidth());Spacer(Modifier.height(10.dp));Text("خرید/سرمایه‌گذاری   ۳۵٪");LinearProgressIndicator(progress={.35f},Modifier.fillMaxWidth())}}}}
@Composable fun AddTx(onAdd:(String,Long,Boolean)->Unit,onCancel:()->Unit){var title by remember{mutableStateOf("")};var amount by remember{mutableStateOf("")};var inc by remember{mutableStateOf(true)};Dialog(onDismissRequest=onCancel){Card(shape=RoundedCornerShape(24.dp)){Column(Modifier.padding(22.dp)){Text("تراکنش جدید",fontSize=22.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(10.dp));OutlinedTextField(title,{title=it},label={Text("عنوان")});OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("مبلغ")},modifier=Modifier.padding(top=8.dp));Row(verticalAlignment=Alignment.CenterVertically){RadioButton(inc,{inc=true});Text("درآمد");RadioButton(!inc,{inc=false});Text("هزینه")};Button(onClick={amount.toLongOrNull()?.let{onAdd(title,it,inc)}},modifier=Modifier.fillMaxWidth()){Text("ثبت")}}}}}
